# Co-cited References Report

**Query:** `higher criticism`

**Source papers analyzed:**
- `W1981106668` — Higher criticism for detecting sparse heterogeneous mixtures (2004, cited 759×)
- `W2127886488` — Higher Criticism for Large-Scale Inference, Especially for Rare and Weak Effects (2015, cited 129×)
- `W2033508629` — Innovated higher criticism for detecting sparse signals in correlated noise (2010, cited 154×)
- `W2003702553` — Properties of higher criticism under strong dependence (2008, cited 72×)
- `W2049704395` — Global testing under sparse alternatives: ANOVA, multiple comparisons and the higher criticism (2011, cited 212×)

**Total unique references found:** 147

## Top references by co-citation frequency

| Rank | Co-cited | Global cites | In-text hits | Title | Authors | Year | DOI |
|---:|---:|---:|---:|---|---|---:|---|
| 1 | 2 | — | 2 | Alignments in Two-Dimensional Random Sets of Points | D. G. Kendall; W. S. Kendall | 1980 |  |
| 2 | 2 | — | 3 | Asymptotic Theory of Certain “Good- Ness of FIt” Criteria Based on Stochastic Processes | T. W. Anderson; D. A. Darling | 1952 |  |
| 3 | 2 | — | 3 | Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing | Y. Benjamini; Y. Hochberg | 1995 |  |
| 4 | 2 | — | 4 | Empirical Processes With Applications to Statistics | G. R. Shorack; J. A. Wellner | 1986 |  |
| 5 | 2 | — | 2 | Goodness-of-FIt Test Statistics That Dominate the Kolmogorov Statistic | R. H. Berk; D. H. Jones | 1979 |  |
| 6 | 2 | — | 1 | Higher Criticism for Individual Signiﬁcances in Several Tables or Parts of Tables. | J. W. Tukey | 1989 |  |
| 7 | 2 | — | 2 | Minimax Detection of a Signal for Lp N-Balls | Y. I. Ingster | 1999 |  |
| 8 | 2 | — | 2 | Some Problems of Hypothesis Testing Leading to Inﬁnitely Divisible Distribution | Y. I. Ingster | 1997 |  |
| 9 | 2 | — | 3 | T13 N: The Higher Criticism. | J. W. Tukey | 1976 |  |
| 10 | 1 | — | 1 | A Comparison of the Benjamini–Hochberg Procedure With Some Bayesian Rules for Multiple Testing. | M. Bogdan; J. Ghosh; T. Tokdar | 2008 |  |
| 11 | 1 | — | 1 | A Comparison of the Lasso and Marginal Regression | C. Genovese; J. Jin; L. Wasserman et al. | 2012 |  |
| 12 | 1 | — | 1 | A Comprehensive Overview of the Cold Spot. | P. Vielva | 2010 |  |
| 13 | 1 | — | 1 | A Constrained L1 Minimization Approach to Sparse Precision Matrix Estimation. | T. Cai; W. Liu; X. Luo | 2010 |  |
| 14 | 1 | — | 1 | A Cram´er Rao Mod- Erate Deviation Theorem for Hotelling’s T 2-Statistic With Applications to Global Tests. | W. Liu; Q. M. Shao | 2013 |  |
| 15 | 1 | — | 1 | A Failure of Likelihood Asymptotics for Normal Mixtures | J. A. Hartigan | 1985 |  |
| 16 | 1 | — | 1 | A Guided Random Walk Through Some High Dimensional Problems. | J. Park; J. Ghosh | 2010 |  |
| 17 | 1 | — | 1 | A Limit Theorem for the Maximum of Normal- Ized Sums of Independent Random Variables | D. A. Darling; P. Erd¨os | 1956 |  |
| 18 | 1 | — | 1 | A Nonparametric Scan Statistic for Multivariate Disease Surveillance. | D. Neill; J. Lingwall | 2007 |  |
| 19 | 1 | — | 1 | A Note on the Asymptotic Distribution of Berk– Jones Type Statistics Under the Null Hypothesis | J. A. Wellner; V. Koltchinskii | 2003 |  |
| 20 | 1 | — | 1 | A Note on the Asymptotic Distribution of Berk–Jones Type Statistics Under the Null Hypothesis | J. A. Wellner; V. Koltchinskii | 2004 |  |
| 21 | 1 | — | 1 | A Tutorial on Support Vector Ma- Chines for Pattern Recognition. | C. Burges | 1998 |  |
| 22 | 1 | — | 1 | Adapting to Unknown Sparsity by Controlling the False Discovery Rate | F. Abramovich; Y. Benjamini; D. Donoho et al. | 2000 |  |
| 23 | 1 | — | 1 | Adaptive Detection of a Signal of Growing Dimension, I, II | Y. I. Ingster | 2002 |  |
| 24 | 1 | — | 1 | Adaptive Discovery of Sparse Signals in Noise | J. Haupt; R. Castro; R. Nowak | 2008 |  |
| 25 | 1 | — | 1 | An Analysis for Un- Replicated Fractional Factorials. | M. Box; D. Meyer | 1986 |  |
| 26 | 1 | — | 1 | An Impossibility Result for High Dimensional Supervised Learning. | M. H. Rohban; P. Ishwar; P. Orteny et al. | 2013 |  |
| 27 | 1 | — | 1 | Asymptotic Bayes-Optimality Under Sparsity of Some Multiple Testing Procedures. | M. Bogdan; A. Chakrabarti; F. Frommlet et al. | 2011 |  |
| 28 | 1 | — | 1 | Asymptotic Distribution of the Likelihood Ratio Statistic in a Prototypical Nonregular Problem | P. J. Bickel; H. Chernoff | 1993 |  |
| 29 | 1 | — | 1 | BagBoosting for Tumor Classiﬁ- Cation With Gene Expression Data. | M. Dettling | 2004 |  |
| 30 | 1 | — | 1 | Bayesian Inference in Statistical Analysis | G. E. P. Box; G. C. Tiao | 1973 |  |
| 31 | 1 | — | 1 | Boosting for Tumor Classiﬁcation With Gene Expression Data. | M. Dettling; P. B¨uhlmann | 2003 |  |
| 32 | 1 | — | 1 | Classification of Sparse High-Dimensional Vectors | Y. I. Ingster; C. Pouet; A. B. Tsybakov | 2009 |  |
| 33 | 1 | — | 3 | Combining Signiﬁcance Levels | B. J. Becker | 1994 |  |
| 34 | 1 | — | 1 | Common Disease-Common Variant Hypothesis | P. El-Fishawy | 2013 |  |
| 35 | 1 | — | 1 | Common Genetic Variation and Human Traits | D. B. Goldstein | 2009 |  |
| 36 | 1 | — | 1 | Compressed Sensing. | D. Donoho | 2006 |  |
| 37 | 1 | — | 1 | Continuous Univariate Distribution, 2nd Ed. 2 | N. L. Johnson; S. Kotz; N. Balakrishan | 1995 |  |
| 38 | 1 | — | 1 | Control of the False Discovery Proportion for Independently Tested Null Hypothe- Ses | Y. Ge; X. Li | 2012 |  |
| 39 | 1 | — | 1 | Cosmological Models Discrimination With Weak Lensing. | S. Pires; J.-L. Starck; A. Amara et al. | 2009 |  |
| 40 | 1 | — | 1 | Cosmological Non-Gaussian Sig- Nature Detection: Comparing Performance of Dif- Ferent Statistical Tests | J. Jin; J.-L. Starck; D. Donoho et al. | 2005 |  |
| 41 | 1 | — | 2 | Covariate Assisted Screening and Estimation | T. Ke; J. Jin; J. Fan | 2014 |  |
| 42 | 1 | — | 1 | Detec- Tion of Sparse Variable Functions | G. Gayraud; Y. I. Ingster | 2011 |  |
| 43 | 1 | — | 1 | Detecting a Target in Very Noisy Data From Multiple Looks | J. Jin | 2004 |  |
| 44 | 1 | — | 1 | Detecting Column Depen- Dence When Rows Are Correlated and Estimating the Strength of the Row Correlation. | O. Muralidharan | 2010 |  |
| 45 | 1 | — | 1 | Detecting Sparse Heterogeneous and Heteroscedastic Mixtures. | T. Cai; J. Jeng; J. Jin | 2011 |  |
| 46 | 1 | — | 1 | Detection Boundary and Higher Criticism Approach for Sparse and Weak Genetic Ef- Fects | Z. Wu; Y. Sun; S. He et al. | 2014 |  |
| 47 | 1 | — | 4 | Detection Boundary for Sparse Mixtures | J. Jin | 2002 |  |
| 48 | 1 | — | 1 | Detection Boundary in Sparse Regression | Y. I. Ingster; A. Tsybakov; N. Verzelen | 2010 |  |
| 49 | 1 | — | 1 | Detection of a Sparse Submatrix of a High-Dimensional Noisy Matrix. | C. Butucea; Y. I. Ingster | 2013 |  |
| 50 | 1 | — | 2 | Detection of an Anomalous Cluster in a Net- Work. | E. Arias-Castro; E. Cand`es; A. Durand | 2011 |  |

## In-context appearances

Across the 5 source paper(s), **Feature Selection by Higher Criticism Thresholding: Optimal Phase Di- Agram** (2009) is the most-referenced work in text, with **5 in-text mentions**.

### 1. Alignments in Two-Dimensional Random Sets of Points (1980)
*D. G. Kendall; W. S. Kendall*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> There are many other potential applications in signal processing; see, for example, [19]–[21]. In spatial statistics Kendall and Kendall [25] developed a statistic closely related to HC∗ n called “pontogram” for the purpose of detecting near-alignments in sets of points. 1.
>
> — p. 3 · marker `[25]`

**In `10.1214/14-STS506`:**

> Additionally, as a measure of goodness of ﬁt, HC is closely related to other goodness-of-ﬁt tests, motivated, however, by the goal of optimal detec- tion of presence of mixture components representing rare/weak signals. We remark that the pontogram of Kendall and Kendall [86] is an instance of HC, a
>
> — p. 9 · marker `[86]`

### 2. Asymptotic Theory of Certain “Good- Ness of FIt” Criteria Based on Stochastic Processes (1952)
*T. W. Anderson; D. A. Darling*

Cited in **2** source paper(s); appears **3** time(s) in text.

**In `10.1214/009053604000000265`:**

> With this notation, we can write HC∗ n = max 1≤i≤α0·n √n[i/n −p(i)]/ p p(i)(1 −p(i)). Despite the closeness of our statistic to the one in [2], note that what we are doing is not arbitrary goodness of ﬁt; instead we are dealing with a speciﬁc kind of multiple hypothesis testing, outside of which the
>
> — p. 5 · marker `[2]`

> As such, it may be compared to many goodness-of-ﬁt procedures where distribution under H1 diﬀers from that of H0 in one tail. Thus, Anderson and Darling [2] deﬁned a goodness-of-ﬁt measure which involves the maximum of the normalized empirical process. Translated into the current setting, this initi
>
> — p. 11 · marker `[2]`

**In `10.1214/14-STS506`:**

> To understand HC, then, one might consider how it diﬀers from other measures of the discrepancy be- tween two distributions. HC includes the element of standardization, which for many readers will suggest comparison to the Anderson–Darling statistic [4]: A(FN,F0) = N · Z |FN(x) −F0(x)|2 F0(x)(1 −F0(
>
> — p. 9 · marker `[4]`

### 3. Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing (1995)
*Y. Benjamini; Y. Hochberg*

Cited in **2** source paper(s); appears **3** time(s) in text.

**In `10.1214/009053604000000265`:**

> Recently considerable interest has been focused on the false discovery rate (FDR)-controlling methodology for simul- taneous inference. In one example of this so-called FDR approach [4], one considers, for k = 1,2,3,. , the k most signiﬁcant p-values.
>
> — p. 10 · marker `[4]`

**In `10.1214/14-STS506`:**

> For example, rather than knowing the true proportion of nonzero eﬀects, one might only want to estimate the largest proportion within which the false discovery rate can be controlled. The literature along this line connects to the work of Benjamini and Hochberg [10] on controlling False Discovery Ra
>
> — p. 8 · marker `[10]`

> 2. 8 Connection to FDR-Controlling Methods HC is connected to Benjamini and Hochberg’s (BH) False Discovery Rate (FDR) control method in large-scale multiple testing [10]. Given N uncor- related tests where π(1) < π(2) < ··· < π(N) are the sorted P-values, introduce the ratios rk = π(k)/(k/N), 1 ≤k
>
> — p. 9 · marker `[10]`

### 4. Empirical Processes With Applications to Statistics (1986)
*G. R. Shorack; J. A. Wellner*

Cited in **2** source paper(s); appears **4** time(s) in text.

**In `10.1214/009053604000000265`:**

> To use HC∗ n to conduct a level-α test, we must ﬁnd a critical value h(n,α): PH0{HC∗ n > h(n,α)} ≤α. Adapting asymptotic theory for the normalized empirical process as in [27], Chapter 16, gives us the following information on the size of h(n,α): Theorem 1. 1.
>
> — p. 5 · marker `[27]`

> 3, and remind the reader that, under H0, HC∗= max 0<t<1/2 Wn(t). The normalized empirical process has been studied carefully by a number of authors, and a summary of results can be found in [27], Chapter 16. There, in (16.
>
> — p. 14 · marker `[27]`

> Numerical experiments support this analysis. Adapting material from [12], or from [27], page 600, it seems we have the following asymptotic law for HC+ n : bnHC+ n −cn →E2 v, where bn = √ 2log log(n), cn = 2log log(n) + 1 2 log(log log(n)) −1 2 log(4π), and the c. d.
>
> — p. 17 · marker `[27]`

**In `10.1214/14-STS506`:**

> HC∗ N can be connected with the maximum of a stan- dardized empirical process; see Donoho and Jin [39]. Using this connection, it follows from [108], page 600, that as N →∞, bNHC∗ N −cN and bNHC+ N −cN converge weakly to the same limit—the standard Gumbel distribution, where bN = p 2log log(N) and c
>
> — p. 4 · marker `[108]`

### 5. Goodness-of-FIt Test Statistics That Dominate the Kolmogorov Statistic (1979)
*R. H. Berk; D. H. Jones*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> However, the maximum is over a < p < b, 0 < a < b < 1, so our remarks on the Anderson–Darling statistic apply. Berk and Jones [5] proposed a goodness-of-ﬁt measure which, adapted to the present setting, may be written as BJ+ n = n · max 1≤i≤n/2 K+(i/n,p(i)), (1. 9) where K+ is deﬁned by K+(t,x) = 
>
> — p. 12 · marker `[5]`

**In `10.1214/14-STS506`:**

> Another perspective is to view the P-values un- derlying HC as obtained from the normal approx- imation to a one-sample test for a known bino- mial proportion, and to consider instead the exact test based on likelihood ratios, or asymptotic tests based instead on KL divergence between the bino- mial
>
> — p. 9 · marker `[12]`

### 6. Higher Criticism for Individual Signiﬁcances in Several Tables or Parts of Tables. (1989)
*J. W. Tukey*

Cited in **2** source paper(s); appears **1** time(s) in text.

**In `10.1214/14-STS506`:**

> 1. 1 HC Basics John Tukey [112–114] coined the term “Higher Criticism”1 and motivated it by the following story. A young scientist administers a total of 250 inde- pendent tests, out of which 11 are signiﬁcant at the level of 5%.
>
> — p. 2 · marker `[112–114]`

### 7. Minimax Detection of a Signal for Lp N-Balls (1999)
*Y. I. Ingster*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> Obviously, in this situation, with εn and µn ﬁxed and known, the opti- mal procedure is simply the likelihood ratio test; a careful analysis of its performance in [23] (cf. also [16] and [17]) tells us the following. Suppose we let εn = n−β for some exponent β ∈(1 2,1), so that the fraction of nonze
>
> — p. 4 · marker `[17]`

**In `10.1214/14-STS506`:**

> On the other hand, when r < ρ(ϑ), the sum of Types I and II errors of any test cannot get substantially smaller than 1. The result was ﬁrst proved by Ingster [65, 66], and then independently by Jin [75, 76]. In other words, in the two-dimensional ϑ-r phase space, the curve r = ρ(ϑ) separates the bou
>
> — p. 20 · marker `[65, 66]`

### 8. Some Problems of Hypothesis Testing Leading to Inﬁnitely Divisible Distribution (1997)
*Y. I. Ingster*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> Obviously, in this situation, with εn and µn ﬁxed and known, the opti- mal procedure is simply the likelihood ratio test; a careful analysis of its performance in [23] (cf. also [16] and [17]) tells us the following. Suppose we let εn = n−β for some exponent β ∈(1 2,1), so that the fraction of nonze
>
> — p. 4 · marker `[16]`

**In `10.1214/14-STS506`:**

> On the other hand, when r < ρ(ϑ), the sum of Types I and II errors of any test cannot get substantially smaller than 1. The result was ﬁrst proved by Ingster [65, 66], and then independently by Jin [75, 76]. In other words, in the two-dimensional ϑ-r phase space, the curve r = ρ(ϑ) separates the bou
>
> — p. 20 · marker `[65, 66]`

### 9. T13 N: The Higher Criticism. (1976)
*J. W. Tukey*

Cited in **2** source paper(s); appears **3** time(s) in text.

**In `10.1214/009053604000000265`:**

> Introduction. In his Class Notes for Statistics 411 at Princeton Uni- versity in 1976 [31], Tukey introduced the notion of the higher criticism by means of a story. A young psychologist administers many hypothesis tests as part of a research project, and ﬁnds that, of 250 tests 11 were signiﬁcant at
>
> — p. 2 · marker `[31]`

**In `10.1214/14-STS506`:**

> 1. 1 HC Basics John Tukey [112–114] coined the term “Higher Criticism”1 and motivated it by the following story. A young scientist administers a total of 250 inde- pendent tests, out of which 11 are signiﬁcant at the level of 5%.
>
> — p. 2 · marker `[112–114]`

> Walther shows that ALR compares favorably with HC and BJ for ﬁnite sample performance, while having similar asymptotic properties under the ARW model dis- cussed below. See [39, 112] for more discussions on the relative merits of HC, BJ and ALR. Additionally, as a measure of goodness of ﬁt, HC is cl
>
> — p. 9 · marker `[39, 112]`

### 10. A Comparison of the Benjamini–Hochberg Procedure With Some Bayesian Rules for Multiple Testing. (2008)
*M. Bogdan; J. Ghosh et al.*

Cited in **1** source paper(s); appears **1** time(s) in text.

**In `10.1214/14-STS506`:**

> [16] and Bogdan et al. [15] from a Bayesian per- spective. Park and Ghosh [100] gave a nice review on recent topics on multiple testing where HC is discussed in detail.
>
> — p. 11 · marker `[15]`

