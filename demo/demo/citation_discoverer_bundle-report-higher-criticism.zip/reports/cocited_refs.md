# Co-cited References Report

**Query:** `higher criticism for sparse mixtures`

**Source papers analyzed:**
- `USER_W1981106668` — (user upload) W1981106668.pdf (None, cited None×)
- `W2788744072` — Detection of Sparse Mixtures: Higher Criticism and Scan Statistic (2018, cited 2×)
- `W1981106668` — Higher criticism for detecting sparse heterogeneous mixtures (2004, cited 759×)
- `W4287327683` — The Impossibility Region for Detecting Sparse Mixtures using the Higher Criticism (2021, cited 3×)

**Total unique references found:** 61

## Top references by co-citation frequency

| Rank | Co-cited | Global cites | In-text hits | Title | Authors | Year | DOI |
|---:|---:|---:|---:|---|---|---:|---|
| 1 | 2 | — | 7 | Asymptotic Theory of Certain” Goodness of FIt” Criteria Based on Stochastic Processes. | T. W. Anderson; D. A. Darling | 1952 |  |
| 2 | 2 | — | 3 | Goodness-of-FIt Test Statistics That Dominate the Kolmogorov Statistics | R. H. Berk; D. H. Jones | 1979 |  |
| 3 | 2 | — | 3 | Higher Criticism for Detecting Sparse Heterogeneous Mixtures | D. L. Donoho; J. Jin | 2004 |  |
| 4 | 2 | — | 2 | On the Exact Berk-Jones Statistics and Their P-Value Calculation | A. Moscovich; B. Nadler; C. Spiegelman | 2016 |  |
| 5 | 2 | — | 1 | Optimal Detection of Heterogeneous and Heteroscedastic Mixtures | T. T. Cai; J. X. Jeng; J. Jin | 2011 |  |
| 6 | 2 | — | 1 | Optimal Detection of Sparse Mixtures Against a Given Null Distribution | T. T. Cai; Y. Wu | 2014 |  |
| 7 | 2 | — | 4 | Some Problems of Hypothesis Testing Leading to Inﬁnitely Divisible Distribution | Y. I. Ingster | 1997 |  |
| 8 | 2 | — | 3 | The Asymptotic Distribution of the Supremum of the Standard- Ized Empirical Distribution Function on Subintervals | D. Jaeschke | 1979 |  |
| 9 | 1 | — | 2 | A Failure of Likelihood Asymptotics for Normal Mixtures | J. A. Hartigan | 1985 |  |
| 10 | 1 | — | 2 | A Limit Theorem for the Maximum of Normal- Ized Sums of Independent Random Variables | D. A. Darling; P. Erd¨os | 1956 |  |
| 11 | 1 | — | 2 | A Note on the Asymptotic Distribution of Berk–Jones Type Statistics Under the Null Hypothesis | J. A. Wellner; V. Koltchinskii | 2004 |  |
| 12 | 1 | — | 1 | A Spatial Scan Statistic | M. Kulldorﬀ | 1997 |  |
| 13 | 1 | — | 2 | Adapting to Unknown Sparsity by Controlling the False Discovery Rate | F. Abramovich; Y. Benjamini; D. Donoho et al. | 2000 |  |
| 14 | 1 | — | 2 | Adaptive Detection of a Signal of Growing Dimension, I, II | Y. I. Ingster | 2002 |  |
| 15 | 1 | — | 2 | Alignments in Two-Dimensional Random Sets of Points | D. G. Kendall; W. S. Kendall | 1980 |  |
| 16 | 1 | — | 2 | Asymptotic Distribution of the Likelihood Ratio Statistic in a Prototypical Nonregular Problem | P. J. Bickel; H. Chernoff | 1993 |  |
| 17 | 1 | — | 2 | Bayesian Inference in Statistical Analysis | G. E. P. Box; G. C. Tiao | 1973 |  |
| 18 | 1 | — | 6 | Combining Significance Levels | B. J. Becker | 1994 |  |
| 19 | 1 | — | 2 | Continuous Univariate Distribution, 2nd Ed. 2 | N. L. Johnson; S. Kotz; N. Balakrishan | 1995 |  |
| 20 | 1 | — | 2 | Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing | Y. Benjamini; Y. Hochberg | 1995 |  |
| 21 | 1 | — | 8 | Detection Boundary for Sparse Mixtures | J. Jin | 2002 |  |
| 22 | 1 | — | 1 | Distribution-Free Tests for Sparse Heterogeneous Mixtures. | E. Arias-Castro; M. Wang | 2017 |  |
| 23 | 1 | — | 6 | Empirical Processes With Applications to Statistics | G. R. Shorack; J. A. Wellner | 1986 |  |
| 24 | 1 | — | 1 | Exact Asymptotics for the Scan Statistic and Fast Alternatives | J. Sharpnack; Arias-Castro | 2016 |  |
| 25 | 1 | — | 1 | Extremes of the Standardized Gaussian Noise | Z. Kabluchko | 2011 |  |
| 26 | 1 | — | 0 | Feature Selection by Higher Criticism Thresholding Achieves the Optimal Phase Diagram | D. L. Donoho; J. Jin | 2009 |  |
| 27 | 1 | — | 0 | Global Testing Under Sparse Alternatives: Anova, Multiple Comparisons and the Higher Criticism | E. Arias-Castro; E. J. Candès; Y. Plan | 2011 |  |
| 28 | 1 | — | 0 | Goodness of FIt Tests in Terms of Local Levels With Special Emphasis on Higher Criticism Tests | V. Gontscharuk; S. Landwehr; H. Finner | 2016 |  |
| 29 | 1 | — | 0 | Higher Criticism for Discriminating Word-Frequency Tables and Testing Authorship | A. Kipnis | 2019 |  |
| 30 | 1 | — | 0 | Higher Criticism for Individual Significances in Several Tables or Parts of Tables | J. W. Tukey | 1989 |  |
| 31 | 1 | — | 0 | Higher Criticism Thresholding: Optimal Feature Selection When Useful Features Are Rare and Weak | D. L. Donoho; J. Jin | 2008 |  |
| 32 | 1 | — | 0 | Higher Criticism to Compare Two Large Frequency Tables, With Sensitivity to Possible Rare and Weak Diﬀerences | D. L. Donoho; A. Kipnis | 2020 |  |
| 33 | 1 | — | 0 | Higher Criticism: P-Values and Criticism | J. Li; D. Siegmund | 2015 |  |
| 34 | 1 | — | 0 | Innovated Higher Criticism for Detecting Sparse Signals in Correlated Noise | P. Hall; J. Jin | 2010 |  |
| 35 | 1 | — | 0 | Limit Results for Ordered Uniform Spacings | I. Bairamov; A. Berred; A. Stepanov | 2010 |  |
| 36 | 1 | — | 2 | Limit Theorems for the Ratio of the Empirical Distribution Function to the True Distribution Function | J. A. Wellner | 1978 |  |
| 37 | 1 | — | 1 | Methods of Statistics | L. H. C. Tippett | 1931 |  |
| 38 | 1 | — | 2 | Minimax Detection of a Signal for Lp N-Balls | Y. I. Ingster | 1999 |  |
| 39 | 1 | — | 0 | Minimax Nonparametric Hypothesis Testing for Ellipsoids and Besov Bodies | Y. I. Ingster; I. A. Suslina | 2000 |  |
| 40 | 1 | — | 2 | Modeling the Joint Statistics of Images in the Wavelet Domain | E. P. Simoncelli | 1999 |  |
| 41 | 1 | — | 2 | Multiple Comparison Procedures | Y. Hochberg; A. C. Tamhane | 1987 |  |
| 42 | 1 | — | 1 | Near-Optimal Detection of Geometric Objects by Fast Multiscale Methods | E. Arias-Castro; D. L. Donoho; X. Huo | 2005 |  |
| 43 | 1 | — | 0 | Nonparametric Statistical Inference | J. D. Gibbons; S. Chakraborti | 2011 |  |
| 44 | 1 | — | 2 | On Asymptotically Optimal Non- Parametric Criteria | A. A. Borovkov; N. M. Sycheva | 1970 |  |
| 45 | 1 | — | 2 | On Multichannel Detection of a Signal of Known Shape | Y. I. Ingster; I. A. Suslina | 2004 |  |
| 46 | 1 | — | 2 | On Multichannel Signal Detection | Y. I. Ingster; O. Lepski | 2002 |  |
| 47 | 1 | — | 2 | On Some Asymptotically Optimal Nonparametric Tests | A. A. Borovkov; N. M. Sycheva | 1968 |  |
| 48 | 1 | — | 2 | On the Law of Frequency of Errors | M. T. Subbotin | 1923 |  |
| 49 | 1 | — | 0 | Probability and Computing: Randomization and Probabilistic Techniques in Algorithms and Data Analysis | M. Mitzenmacher; E. Upfal | 2017 |  |
| 50 | 1 | — | 2 | Reliable and Questionable Signiﬁcance in a Series of Statistical Tests | J. Broˇzek; K. Tiede | 1952 |  |

## In-context appearances

Across the 4 source paper(s), **Detection Boundary for Sparse Mixtures** (2002) is the most-referenced work in text, with **8 in-text mentions**.

### 1. Asymptotic Theory of Certain” Goodness of FIt” Criteria Based on Stochastic Processes. (1952)
*T. W. Anderson; D. A. Darling*

Cited in **2** source paper(s); appears **7** time(s) in text.

**In `10.1214/009053604000000265`:**

> With this notation, we can write HC∗ n = max 1≤i≤α0·n √n[i/n −p(i)]/ p p(i)(1 −p(i)). Despite the closeness of our statistic to the one in [2], note that what we are doing is not arbitrary goodness of ﬁt; instead we are dealing with a speciﬁc kind of multiple hypothesis testing, outside of which the
>
> — p. 5 · marker `[2]`

> As such, it may be compared to many goodness-of-ﬁt procedures where distribution under H1 diﬀers from that of H0 in one tail. Thus, Anderson and Darling [2] deﬁned a goodness-of-ﬁt measure which involves the maximum of the normalized empirical process. Translated into the current setting, this initi
>
> — p. 11 · marker `[2]`

> With this notation, we can write HC∗ n = max 1≤i≤α0·n √n[i/n −p(i)]/ p p(i)(1 −p(i)). Despite the closeness of our statistic to the one in [2], note that what we are doing is not arbitrary goodness of ﬁt; instead we are dealing with a speciﬁc kind of multiple hypothesis testing, outside of which the
>
> — p. 5 · marker `[2]`

> As such, it may be compared to many goodness-of-ﬁt procedures where distribution under H1 diﬀers from that of H0 in one tail. Thus, Anderson and Darling [2] deﬁned a goodness-of-ﬁt measure which involves the maximum of the normalized empirical process. Translated into the current setting, this initi
>
> — p. 11 · marker `[2]`

**In `1802.08715v1`:**

> ) When F is known, the problem is that of goodness-of-ﬁt testing, albeit with alternatives of the form (2) in mind. Donoho and Jin [7] opened this investigation with the analysis of various tests, including the max test based on maxi Xi and a variant of the Anderson-Darling test [1]. Seeing as a pro
>
> — p. 2 · marker `[1]`

> An important example is in spatial statistics (itself a rather wide area), where the detection of ‘hot spots’, meaning areas of unusually high concentration, has been considered for quite some time [13]. An early contribution to this literature is that of Naus [15], who considered the distribution o
>
> — p. 3 · marker `[0,1]`

> 14 Proof. Under the null, each Pi,j is uniformly distributed in [0,1]. Thus the union bound gives P0(Tn ≤1/n3) ≤n2 P0(Pi,j ≤1/n3) = n2/n3 = 1/n →0, (68) which concludes the proof.
>
> — p. 14 · marker `[0,1]`

### 2. Goodness-of-FIt Test Statistics That Dominate the Kolmogorov Statistics (1979)
*R. H. Berk; D. H. Jones*

Cited in **2** source paper(s); appears **3** time(s) in text.

**In `10.1214/009053604000000265`:**

> However, the maximum is over a < p < b, 0 < a < b < 1, so our remarks on the Anderson–Darling statistic apply. Berk and Jones [5] proposed a goodness-of-ﬁt measure which, adapted to the present setting, may be written as BJ+ n = n · max 1≤i≤n/2 K+(i/n,p(i)), (1. 9) where K+ is deﬁned by K+(t,x) = 
>
> — p. 12 · marker `[5]`

> However, the maximum is over a < p < b, 0 < a < b < 1, so our remarks on the Anderson–Darling statistic apply. Berk and Jones [5] proposed a goodness-of-ﬁt measure which, adapted to the present setting, may be written as BJ+ n = n · max 1≤i≤n/2 K+(i/n,p(i)), (1. 9) where K+ is deﬁned by K+(t,x) = 
>
> — p. 12 · marker `[5]`

**In `1802.08715v1`:**

> More recently, Moscovich et al. [14] analyzed a goodness-of-ﬁt (BJ) test proposed by Berk and Jones [4] in the same setting. For t ∈R, deﬁne Nn(t) = #{i ∶Xi ≥t}.
>
> — p. 2 · marker `[4]`

### 3. Higher Criticism for Detecting Sparse Heterogeneous Mixtures (2004)
*D. L. Donoho; J. Jin*

Cited in **2** source paper(s); appears **3** time(s) in text.

**In `1802.08715v1`:**

> In such a situation, we will say that a test procedure ‘achieves the detection boundary’, or is ‘ﬁrst-order optimal’ (or simply ‘optimal’), if it is fully powerful when r > ρ(β). Such detection boundaries where derived for other models, for example, in [5–7]. We also mention that the situation where
>
> — p. 2 · marker `[5–7]`

> ) When F is known, the problem is that of goodness-of-ﬁt testing, albeit with alternatives of the form (2) in mind. Donoho and Jin [7] opened this investigation with the analysis of various tests, including the max test based on maxi Xi and a variant of the Anderson-Darling test [1]. Seeing as a pro
>
> — p. 2 · marker `[7]`

> (13) Indeed, φs●,t●relies on oracle knowledge of (ε,µ). To the best of our knowledge, this is the ﬁrst time that such tests are considered in the line of work that concerns us here with roots in the work of Ingster [10] and Donoho and Jin [7]. The main reason for considering these tests in the prese
>
> — p. 4 · marker `[7]`

### 4. On the Exact Berk-Jones Statistics and Their P-Value Calculation (2016)
*A. Moscovich; B. Nadler et al.*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `1802.08715v1`:**

> More recently, Moscovich et al. [14] analyzed a goodness-of-ﬁt (BJ) test proposed by Berk and Jones [4] in the same setting. For t ∈R, deﬁne Nn(t) = #{i ∶Xi ≥t}.
>
> — p. 2 · marker `[14]`

> We control this statistic under the null hypothesis by a simple application of the union bound. A more reﬁned control seems possible in view of [14], where the limiting distribution of (7) is obtained. Proposition 9.
>
> — p. 13 · marker `[14]`

### 5. Optimal Detection of Heterogeneous and Heteroscedastic Mixtures (2011)
*T. T. Cai; J. X. Jeng et al.*

Cited in **2** source paper(s); appears **1** time(s) in text.

**In `1802.08715v1`:**

> In such a situation, we will say that a test procedure ‘achieves the detection boundary’, or is ‘ﬁrst-order optimal’ (or simply ‘optimal’), if it is fully powerful when r > ρ(β). Such detection boundaries where derived for other models, for example, in [5–7]. We also mention that the situation where
>
> — p. 2 · marker `[5–7]`

### 6. Optimal Detection of Sparse Mixtures Against a Given Null Distribution (2014)
*T. T. Cai; Y. Wu*

Cited in **2** source paper(s); appears **1** time(s) in text.

**In `1802.08715v1`:**

> In such a situation, we will say that a test procedure ‘achieves the detection boundary’, or is ‘ﬁrst-order optimal’ (or simply ‘optimal’), if it is fully powerful when r > ρ(β). Such detection boundaries where derived for other models, for example, in [5–7]. We also mention that the situation where
>
> — p. 2 · marker `[5–7]`

### 7. Some Problems of Hypothesis Testing Leading to Inﬁnitely Divisible Distribution (1997)
*Y. I. Ingster*

Cited in **2** source paper(s); appears **4** time(s) in text.

**In `10.1214/009053604000000265`:**

> Obviously, in this situation, with εn and µn ﬁxed and known, the opti- mal procedure is simply the likelihood ratio test; a careful analysis of its performance in [23] (cf. also [16] and [17]) tells us the following. Suppose we let εn = n−β for some exponent β ∈(1 2,1), so that the fraction of nonze
>
> — p. 4 · marker `[16]`

> Obviously, in this situation, with εn and µn ﬁxed and known, the opti- mal procedure is simply the likelihood ratio test; a careful analysis of its performance in [23] (cf. also [16] and [17]) tells us the following. Suppose we let εn = n−β for some exponent β ∈(1 2,1), so that the fraction of nonze
>
> — p. 4 · marker `[16]`

**In `1802.08715v1`:**

> 22]. Rather, our contribution is in line with the testing problems studied by Ingster [10] in the context of the normal sequence model, where F above corresponds to the standard normal distribution. In that setting, Ingster considered the following parameterization ε = εn = n−β, µ = µn = √ 2r log n,
>
> — p. 1 · marker `[10]`

> (13) Indeed, φs●,t●relies on oracle knowledge of (ε,µ). To the best of our knowledge, this is the ﬁrst time that such tests are considered in the line of work that concerns us here with roots in the work of Ingster [10] and Donoho and Jin [7]. The main reason for considering these tests in the prese
>
> — p. 4 · marker `[10]`

### 8. The Asymptotic Distribution of the Supremum of the Standard- Ized Empirical Distribution Function on Subintervals (1979)
*D. Jaeschke*

Cited in **2** source paper(s); appears **3** time(s) in text.

**In `10.1214/009053604000000265`:**

> 20), they show that max 0<t<α0 Wn(t) p 2log log(n) p→1, n →∞, (2. 11) by an argument that depends on the work of Jaeschke [22]. This, in turn, depends on the approximation of Wn by a Brownian bridge and on a result of Darling and Erd¨os [11], which says that, if B(t) is standard Brownian motion star
>
> — p. 14 · marker `[22]`

> 20), they show that max 0<t<α0 Wn(t) p 2log log(n) p→1, n →∞, (2. 11) by an argument that depends on the work of Jaeschke [22]. This, in turn, depends on the approximation of Wn by a Brownian bridge and on a result of Darling and Erd¨os [11], which says that, if B(t) is standard Brownian motion star
>
> — p. 14 · marker `[22]`

**In `1802.08715v1`:**

> The main work goes into controlling this statistic under the null hypothesis. The limiting distribution of higher criticism can be derived from [11] and the limiting distributions of some variants of the scan statistic are known under other models [12, 16]. We will not pursue such a ﬁne result here,
>
> — p. 12 · marker `[11]`

### 9. A Failure of Likelihood Asymptotics for Normal Mixtures (1985)
*J. A. Hartigan*

Cited in **1** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> HIGHER CRITICISM FOR DETECTING MIXTURES 5 Bickel and Chernoﬀ[6] and Hartigan [14] have shown that the usual gen- eralized likelihood ratio test maxε,µ(dP (n) 1 (ε,µ)/dP (n) 0 )(X) has nonstandard behavior in this setting; in fact the maximized ratio tends to ∞under H0. It is not clear that this test
>
> — p. 5 · marker `[14]`

> HIGHER CRITICISM FOR DETECTING MIXTURES 5 Bickel and Chernoﬀ[6] and Hartigan [14] have shown that the usual gen- eralized likelihood ratio test maxε,µ(dP (n) 1 (ε,µ)/dP (n) 0 )(X) has nonstandard behavior in this setting; in fact the maximized ratio tends to ∞under H0. It is not clear that this test
>
> — p. 5 · marker `[14]`

### 10. A Limit Theorem for the Maximum of Normal- Ized Sums of Independent Random Variables (1956)
*D. A. Darling; P. Erd¨os*

Cited in **1** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> 11) by an argument that depends on the work of Jaeschke [22]. This, in turn, depends on the approximation of Wn by a Brownian bridge and on a result of Darling and Erd¨os [11], which says that, if B(t) is standard Brownian motion starting at B(0) = 0, then sup [1,u] B(t) √ t 1 √2log log u p→1, u →∞.
>
> — p. 14 · marker `[11]`

> 11) by an argument that depends on the work of Jaeschke [22]. This, in turn, depends on the approximation of Wn by a Brownian bridge and on a result of Darling and Erd¨os [11], which says that, if B(t) is standard Brownian motion starting at B(0) = 0, then sup [1,u] B(t) √ t 1 √2log log u p→1, u →∞.
>
> — p. 14 · marker `[11]`

