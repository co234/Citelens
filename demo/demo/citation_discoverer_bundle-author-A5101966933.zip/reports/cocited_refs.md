# Co-cited References Report

**Query:** `author:A5101966933`

**Source papers analyzed:**
- `W1981106668` — Higher criticism for detecting sparse heterogeneous mixtures (2004, cited 759×)
- `W2027966435` — Fast community detection by SCORE (2014, cited 319×)
- `W2081769927` — Estimating the Null and the Proportion of Nonnull Effects in Large-Scale Multiple Comparisons (2007, cited 167×)

**Total unique references found:** 91

## Top references by co-citation frequency

| Rank | Co-cited | Global cites | In-text hits | Title | Authors | Year | DOI |
|---:|---:|---:|---:|---|---|---:|---|
| 1 | 2 | — | 2 | Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing. | Y. Benjamini; Y. Hochberg | 1995 |  |
| 2 | 2 | — | 2 | Which Part of the Sample Contains the Information? | J. W. Tukey | 1965 |  |
| 3 | 1 | — | 1 | A Failure of Likelihood Asymptotics for Normal Mixtures. | J. A. Hartigan | 1985 |  |
| 4 | 1 | — | 1 | A Limit Theorem for the Maximum of Normal- Ized Sums of Independent Random Variables. | D. A. Darling; P. Erd¨os | 1956 |  |
| 5 | 1 | — | 8 | A Nonparametric View of Network Models and Newman-Girvan and Other Modularities | P. J. Bickel; A. Chen | 2009 |  |
| 6 | 1 | — | 1 | A Note on the Asymptotic Distribution of Berk–Jones Type Statistics Under the Null Hypothesis | J. A. Wellner; V. Koltchinskii | 2004 |  |
| 7 | 1 | — | 5 | A Stochastic Process Approach to False Discovery Control | C. Genovese; L. Wasserman | 2004 |  |
| 8 | 1 | — | 4 | A Survey of Statistical Network Models | A. Goldenberg; A. Zheng; S. Fienberg et al. | 2009 |  |
| 9 | 1 | — | 1 | A Wavelet Tour of Signal Processing | S. Mallat | 1998 |  |
| 10 | 1 | — | 1 | Adapting to Unknown Sparsity by Controlling the False Discovery Rate. | F. Abramovich; Y. Benjamini; D. Donoho et al. | 2000 |  |
| 11 | 1 | — | 4 | Adapting to Unknown Sparsity by Controlling the False Discovery Rate. | F. Abramovich; Y. Benjamini; D. Donoho et al. | 2006 |  |
| 12 | 1 | — | 1 | Adaptive Detection of a Signal of Growing Dimension, I, II. | Y. I. Ingster | 2002 |  |
| 13 | 1 | — | 1 | Alignments in Two-Dimensional Ran- Dom Sets of Points. | D. G. Kendall; W. S. Kendall | 1980 |  |
| 14 | 1 | — | 2 | An Information FLow Model for Conﬂict and FIssion in Small Groups. | W. Zachary | 1977 |  |
| 15 | 1 | — | 1 | Asymptotic Distribution of the Likelihood Ratio Statistic in a Prototypical Nonregular Problem. | P. J. Bickel; H. Chernoff | 1993 |  |
| 16 | 1 | — | 2 | Asymptotic Theory of Certain “Good- Ness of FIt” Criteria Based on Stochastic Processes. | T. W. Anderson; D. A. Darling | 1952 |  |
| 17 | 1 | — | 1 | Bayesian Inference in Statistical Analysis. | G. E. P. Box; G. C. Tiao | 1973 |  |
| 18 | 1 | — | 1 | Bulk Universality for Generalized Wigner Matrices | L. Erdős; H.-T. Yau; J. Yin | 2012 |  |
| 19 | 1 | — | 1 | Cellular Gene Expression Upon Human Immunod- Eﬁciency Virus Type 1 Infection of CD4+-T-Cell Lines. | A. Van’t Wout | 2003 |  |
| 20 | 1 | — | 1 | Coexpression Net- Work Based on Natural Variation in Human Gene Expression Reveals Gene Interac- Tions and Functions. | R. Nayak; M. Kearns; R. Spielman et al. | 2009 |  |
| 21 | 1 | — | 3 | Combining Signiﬁcance Levels. | B. J. Becker | 1994 |  |
| 22 | 1 | — | 1 | Community Identiﬁcation in Networks With Unbal- Anced Structure. | S. Zhang; H. Zhao | 2012 |  |
| 23 | 1 | — | 17 | Consistency of Community Detec- Tion in Network Under Degree-Corrected Stochastic Block Models. | Y. Zhao; L. Levina; J. Zhu | 2011 |  |
| 24 | 1 | — | 4 | Consistent Adjacency-Spectral Clustering Partitioning for the Stochastic Model When the Model Parameters Are Unknown | D. Fishkind; D. Sussman; M. Tang et al. | 2012 |  |
| 25 | 1 | — | 1 | Continuous Univariate Distribution, 2nd Ed. 2. | N. L. Johnson; S. Kotz; N. Balakrishan | 1995 |  |
| 26 | 1 | — | 4 | Detection Boundary for Sparse Mixtures. | J. Jin | 2002 |  |
| 27 | 1 | — | 1 | Eigenspokes: Surprising Patterns and Scalable Community Chipping in Large Graphs. | B. A. Prakah; A. Sridharan; M. Seshadri et al. | 2010 |  |
| 28 | 1 | — | 5 | Empirical Bayes Analysis of a Microarray Experiment | B. Efron; R. Tibshirani; J. Storey et al. | 2001 |  |
| 29 | 1 | — | 1 | Empirical Model-Building and Response Surfaces | G. E. P. Box; N. R. Draper | 1987 |  |
| 30 | 1 | — | 3 | Empirical Processes With Applications to Statistics. | G. R. Shorack; J. A. Wellner | 1986 |  |
| 31 | 1 | — | 1 | Estimating the Null and the Proportion of Non-Null Eﬀects in Large-Scale Multiple Comparisons | J. Jin; T. Cai | 2006 |  |
| 32 | 1 | — | 6 | Estimating the Proportion of False Null Hypotheses Among a Large Number of Independent Tested Hypotheses | M. Meinshausen; J. Rice | 2006 |  |
| 33 | 1 | — | 7 | Estimation and Conﬁdence Sets for Sparse Normal Mixtures | T. Cai; J. Jin; M. Low | 2005 |  |
| 34 | 1 | — | 4 | Finding Community Structure in Networks Using the Eigenvectors of Matrices. | M. E. J. Newman | 2006 |  |
| 35 | 1 | — | 1 | Forest Density Estimation | H. Liu; M. Xu; H. Gu et al. | 2011 |  |
| 36 | 1 | — | 1 | Fourier Methods for Estimating Mixing Densities and Distributions. | C.-H. Zhang | 1990 |  |
| 37 | 1 | — | 2 | Gene Expression Proﬁles in Hereditary Breast Cancer | I. Hedenfalk; D. Duggen; Y. Chen | 2001 |  |
| 38 | 1 | — | 1 | Goodness-of-FIt Test Statistics That Dominate the Kolmogorov Statistic. | R. H. Berk; D. H. Jones | 1979 |  |
| 39 | 1 | — | 4 | Higher Criticism for Detecting Sparse Hetero- Geneous Mixtures | D. Donoho; J. Jin | 2004 |  |
| 40 | 1 | — | 0 | Higher Criticism for Individual Signiﬁcances in Several Tables or Parts of Tables | J. W. Tukey | 1989 |  |
| 41 | 1 | — | 17 | Large-Scale Simultaneous Hypothesis Testing: The Choice of a Null Hypothesis | B. Efron | 2004 |  |
| 42 | 1 | — | 1 | Limit Theorems for the Ratio of the Empirical Distribution Function to the True Distribution Function | J. A. Wellner | 1978 |  |
| 43 | 1 | — | 4 | Matrix Analysis | R. A. Horn; C. R. Johnson | 1985 |  |
| 44 | 1 | — | 1 | Matrix Computations, 3rd Ed | G. H. Golub; C. F. Van Loan | 1996 |  |
| 45 | 1 | — | 1 | Minimax Detection of a Signal for Lp N-Balls. | Y. I. Ingster | 1999 |  |
| 46 | 1 | — | 0 | Minimax Nonparametric Hypothesis Testing for Ellipsoids and Besov Bodies. | Y. I. Ingster; I. A. Suslina | 2000 |  |
| 47 | 1 | — | 1 | Model Selection for Degree- Corrected Block Model. | X. Yan; J. Jensen; F. Krzakala | 2014 |  |
| 48 | 1 | — | 1 | Modeling Homophily and Stochastic Equivalence in Symmetric Relational Data | P. Hoff | 2007 |  |
| 49 | 1 | — | 1 | Modeling the Joint Statistics of Images in the Wavelet Do- Main. | E. P. Simoncelli | 1999 |  |
| 50 | 1 | — | 1 | Multiple Comparison Procedures. | Y. Hochberg; A. C. Tamhane | 1987 |  |

## In-context appearances

Across the 3 source paper(s), **Consistency of Community Detec- Tion in Network Under Degree-Corrected Stochastic Block Models.** (2011) is the most-referenced work in text, with **17 in-text mentions**.

### 1. Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing. (1995)
*Y. Benjamini; Y. Hochberg*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> Recently considerable interest has been focused on the false discovery rate (FDR)-controlling methodology for simul- taneous inference. In one example of this so-called FDR approach [4], one considers, for k = 1,2,3,. , the k most signiﬁcant p-values.
>
> — p. 10 · marker `[4]`

**In `312499ee99f4`:**

> That is, (Xj|Hj is true) ∼ F0. Since the pioneering work of Benjamini and Hochberg [2], which introduced the False Discovery Rate (FDR)-controlling procedures, research on large-scale simultaneous testing has been very active. See, for example, [1, 4, 6, 7, 8, 10, 17, 19].
>
> — p. 2 · marker `[2]`

### 2. Which Part of the Sample Contains the Information? (1965)
*J. W. Tukey*

Cited in **2** source paper(s); appears **2** time(s) in text.

**In `10.1214/009053604000000265`:**

> Which part of the sample contains the information? Underlying our results is a set of insights about “where to look” for evidence against H0 [30], how the evidence may not be in the “obvious” place and how the adaptation in HC∗automatically ensures that the best evidence will be included in making t
>
> — p. 6 · marker `[30]`

**In `10.1214/14-AOS1265`:**

> Where is the information: Spectral analysis heuristics. In [33], John Tukey mentioned an idea that can serve as a general guideline for statistical inference. Tukey’s idea is that before we tackle any statistical problem, we should think about “which part of the data contains the information”: the “
>
> — p. 4 · marker `[33]`

### 3. A Failure of Likelihood Asymptotics for Normal Mixtures. (1985)
*J. A. Hartigan*

Cited in **1** source paper(s); appears **1** time(s) in text.

**In `10.1214/009053604000000265`:**

> HIGHER CRITICISM FOR DETECTING MIXTURES 5 Bickel and Chernoﬀ[6] and Hartigan [14] have shown that the usual gen- eralized likelihood ratio test maxε,µ(dP (n) 1 (ε,µ)/dP (n) 0 )(X) has nonstandard behavior in this setting; in fact the maximized ratio tends to ∞under H0. It is not clear that this test
>
> — p. 5 · marker `[14]`

### 4. A Limit Theorem for the Maximum of Normal- Ized Sums of Independent Random Variables. (1956)
*D. A. Darling; P. Erd¨os*

Cited in **1** source paper(s); appears **1** time(s) in text.

**In `10.1214/009053604000000265`:**

> 11) by an argument that depends on the work of Jaeschke [22]. This, in turn, depends on the approximation of Wn by a Brownian bridge and on a result of Darling and Erd¨os [11], which says that, if B(t) is standard Brownian motion starting at B(0) = 0, then sup [1,u] B(t) √ t 1 √2log log u p→1, u →∞.
>
> — p. 14 · marker `[11]`

### 5. A Nonparametric View of Network Models and Newman-Girvan and Other Modularities (2009)
*P. J. Bickel; A. Chen*

Cited in **1** source paper(s); appears **8** time(s) in text.

**In `10.1214/14-AOS1265`:**

> Tools and discoveries in this area could potentially reshape scientiﬁc data analysis and even have impacts on daily life (friendship, marketing, security). A problem that is of major interest is “network community detection” [4, 8, 9, 17, 27–29, 31, 36, 37]. Given an n-node (undirected) graph N = (V
>
> — p. 2 · marker `[4, 8, 9, 17, 27–29, 31, 36, 37]`

> The stochastic block model (BM) is a classic network model. The BM is mathematically simple and relatively easy to analyze [4]. However, it is too restrictive to reﬂect some prominent empirical characteristics of real net- works.
>
> — p. 2 · marker `[4]`

> Compared to the BM, these models are more ﬂexible, but unfortunately are also more complicated and so comparably much harder to analyze. DCBM is a recent model proposed by [22], which has become increasingly popular in network analysis [4, 8, 22, 34, 37]. Compared to the BM, DCBM
>
> — p. 2 · marker `[4, 8, 22, 34, 37]`

> Comparison with the proﬁle likelihood approach. The proﬁle like- lihood (PL) approach is a well-known method for community detection [4, 22, 37]. The method was ﬁrst proposed by Karrer and Newman [22] and was later carefully analyzed by Zhao et al.
>
> — p. 10 · marker `[4, 22, 37]`

> 3), for details. In principle, PL is computationally NP-hard [4] (and so are many mod- ularity methods; see, e. g.
>
> — p. 10 · marker `[4]`

> The results are similar to those reported in [2], page 16. The web blog data is also analyzed in [4], with an error rate of 61/1228. 1.
>
> — p. 12 · marker `[4]`

> 25 + 0. 0625 × [0,1,2,3,4], we generate the label vector randomly by (ℓi −1) i. i.
>
> — p. 28 · marker `[0,1,2,3,4]`

> We also include the pseudo Likelihood algorithm (pseudoL) by Amini et al. [4] for comparison. For parameters (a,c0,d0) and γ ∈{0.
>
> — p. 29 · marker `[4]`

### 6. A Note on the Asymptotic Distribution of Berk–Jones Type Statistics Under the Null Hypothesis (2004)
*J. A. Wellner; V. Koltchinskii*

Cited in **1** source paper(s); appears **1** time(s) in text.

**In `10.1214/009053604000000265`:**

> 4 below shows that K+(t,x) behaves as 1 2((t−x)2)/(x(1−x)), so it should not be surprising that for our measure of performance the detection boundary of BJ+ n is the same as that of HC∗. (Note, however, that full justiﬁcation of the asymptotic claim in [5] has only recently been provided; see [35] f
>
> — p. 12 · marker `[35]`

### 7. A Stochastic Process Approach to False Discovery Control (2004)
*C. Genovese; L. Wasserman*

Cited in **1** source paper(s); appears **5** time(s) in text.

**In `312499ee99f4`:**

> Since the pioneering work of Benjamini and Hochberg [2], which introduced the False Discovery Rate (FDR)-controlling procedures, research on large-scale simultaneous testing has been very active. See, for example, [1, 4, 6, 7, 8, 10, 17, 19]. FDR procedures are based on the p-values, which measure t
>
> — p. 2 · marker `[1, 4, 6, 7, 8, 10, 17, 19]`

> 1)- (2. 2) and has been widely used in the literature; see for example [7, 10]. The model treats the test statistics Xj as samples from a two-component Gaussian mixture: Xj ∼(1 −ǫ)N(µ0, σ2 0) + ǫN(µj, σ2 j ), 1 ≤j ≤n, (2.
>
> — p. 13 · marker `[7, 10]`

> [4], and Jin [13]. See also [8, 10]. The ﬁrst two approaches only provide consistent estima- tors under a condition which Genovese and Wasserman call “purity” [10].
>
> — p. 15 · marker `[8, 10]`

> See also [8, 10]. The ﬁrst two approaches only provide consistent estima- tors under a condition which Genovese and Wasserman call “purity” [10]. These approaches do not perform well in the current setting as the purity condition is not satisﬁed; see Lemma 3.
>
> — p. 15 · marker `[10]`

> bound to be consistent. Similar results can be found in Genovese and Wasserman [10]. Unfortunately, the purity condition generally does not hold in our settings.
>
> — p. 17 · marker `[10]`

### 8. A Survey of Statistical Network Models (2009)
*A. Goldenberg; A. Zheng et al.*

Cited in **1** source paper(s); appears **4** time(s) in text.

**In `10.1214/14-AOS1265`:**

> For example, the BM implies that the nodes within each community have the same expected degrees, and that the distribution of degrees within the community is Poisson. However, this conﬂicts with the empirical obser- vation that in many natural networks, the degrees follow approximately a power-law d
>
> — p. 2 · marker `[14, 23]`

> However, this conﬂicts with the empirical obser- vation that in many natural networks, the degrees follow approximately a power-law distribution [14, 23]. In a diﬀerent line of development, there are the p∗model and the ex- ponential random graph model (ERGM) [14]. Compared to the BM, these models a
>
> — p. 2 · marker `[14]`

> COMMUNITY DETECTION BY SCORE 3 allows for degree heterogeneity and is much more realistic: for each node, it uses a free parameter to model the degree. The comparison of DCBM with the p∗model and the ERGM [14, 23] is not obvious, given that all of them use a large number of parameters. However, in s
>
> — p. 3 · marker `[14, 23]`

> g. , linkage prediction [14]). In this paper, we have assumed the number of communities K as known.
>
> — p. 31 · marker `[14]`

### 9. A Wavelet Tour of Signal Processing (1998)
*S. Mallat*

Cited in **1** source paper(s); appears **1** time(s) in text.

**In `312499ee99f4`:**

> It is not hard to show that |ψ′(tn(γ))| ≤ǫn · | R eitn(γ)u[(u − µ0)h(u)]du|, where the integral is the Fourier transform of the function (u−µ0)h(u) at frequency tn(γ). By the Riemann-Lebesgue Lemma [16], |ψ′(tn(γ))| = o(t−k n (γ)) if the k-th derivative of h(u) is absolutely integrable. In particula
>
> — p. 12 · marker `[16]`

### 10. Adapting to Unknown Sparsity by Controlling the False Discovery Rate. (2000)
*F. Abramovich; Y. Benjamini et al.*

Cited in **1** source paper(s); appears **1** time(s) in text.

**In `10.1214/009053604000000265`:**

> How does such a procedure behave in the current setting? We begin by pointing out that Abramovich, Benjamini, Donoho and Johnstone [1] have analyzed the behavior of FDR in exactly the kind of mixture model described above in (1. 3)–(1.
>
> — p. 10 · marker `[1]`

